-- ═══════════════════════════════════════════════════════
--  mejora1_password_resets.sql
--  Migración — Mejora 1: Recuperación de contraseña
--  Ejecutar sobre la BD canchaya_bd ya existente
--  (no borra ni afecta las tablas actuales)
-- ═══════════════════════════════════════════════════════

USE canchaya_bd;

CREATE TABLE IF NOT EXISTS password_resets (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id    INT NOT NULL,
    token         VARCHAR(64) NOT NULL UNIQUE,
    expira_en     DATETIME NOT NULL,
    usado         TINYINT(1) NOT NULL DEFAULT 0,
    creado_en     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_reset_usuario FOREIGN KEY (usuario_id)
        REFERENCES usuarios(id) ON DELETE CASCADE,

    INDEX idx_reset_token (token)
) ENGINE=InnoDB;
