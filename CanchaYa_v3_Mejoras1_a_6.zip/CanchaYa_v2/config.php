<?php
/* ═══════════════════════════════════════════════════════
   config.php — CanchaYa
   Configuración general del sitio y del correo saliente
   (Mejora 1: recuperación de contraseña / Mejora 2: notificaciones)
═══════════════════════════════════════════════════════ */

// URL base donde vive el proyecto (sin slash final).
// Se usa para armar el enlace de restablecimiento en el correo.
// Ej: en XAMPP local suele ser 'http://localhost/CANCHA-YA'
define('SITE_URL', 'http://localhost/CANCHA-YA');

// ── Configuración SMTP ────────────────────────────────
// Si SMTP_HOST queda vacío, enviar_correo() usa la función mail()
// nativa de PHP como respaldo (requiere sendmail configurado).
// Para Gmail: activar verificación en 2 pasos y crear una
// "contraseña de aplicación" — nunca uses tu contraseña normal aquí.
define('SMTP_HOST', '');              // ej: 'smtp.gmail.com'
define('SMTP_PORT', 587);
define('SMTP_USER', '');              // ej: 'tu_correo@gmail.com'
define('SMTP_PASS', '');              // contraseña de aplicación
define('SMTP_FROM_EMAIL', 'no-reply@canchaya.com');
define('SMTP_FROM_NAME', 'CanchaYa');

// Minutos de validez del token de recuperación de contraseña
define('RESET_TOKEN_MINUTOS', 30);

// Zona horaria del negocio. NO se cambia la zona global de PHP (date_default_timezone_set)
// para no alterar el cálculo de expiración de los tokens de la Mejora 1; estos helpers
// se usan solo donde importa la hora local de Panamá (¿ya se jugó la reserva?).
define('ZONA_HORARIA', 'America/Panama');

function ahora_panama(): DateTime
{
    return new DateTime('now', new DateTimeZone(ZONA_HORARIA));
}

/** Convierte la fecha y hora de una reserva (hora local de Panamá) en un DateTime comparable. */
function fecha_hora_panama(string $fecha, string $hora): DateTime
{
    return new DateTime($fecha . ' ' . $hora, new DateTimeZone(ZONA_HORARIA));
}

// ── Mejora 4: pagos en línea ──────────────────────────
// 'simulado' → pasarela de pruebas: valida los datos, aprueba/rechaza
//              según reglas de prueba y NO mueve dinero real.
// 'produccion' → requiere implementar el conector real en api/pagos.php
//              (ver funciones cobrar_tarjeta_real() y cobrar_yappy_real()).
define('PAGOS_MODO', 'simulado');

// Credenciales de Yappy Comercial (Banco General) — solo modo producción.
define('YAPPY_MERCHANT_ID', '');
define('YAPPY_API_KEY', '');

// ── Notificaciones por SMS (Mejora 2 ampliada) ────────
// Proveedor: Twilio. Si queda vacío, los SMS se registran en logs/sms.log.
define('TWILIO_SID', '');
define('TWILIO_TOKEN', '');
define('TWILIO_FROM', '');           // ej: '+15005550006'
