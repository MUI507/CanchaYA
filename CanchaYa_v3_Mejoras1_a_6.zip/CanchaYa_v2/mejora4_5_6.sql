-- ═══════════════════════════════════════════════════════
--  mejora4_5_6.sql
--  Migración — Mejoras 4 (pagos), 5 (reseñas) y 6 (reportes/SMS)
--  Ejecutar sobre la BD canchaya_bd ya existente
--  (no borra ni afecta las tablas actuales)
-- ═══════════════════════════════════════════════════════

USE canchaya_bd;

-- Mejora 4: pagos en línea ---------------------------------
CREATE TABLE IF NOT EXISTS pagos (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    reserva_id       INT NOT NULL,
    metodo           ENUM('tarjeta','yappy','efectivo') NOT NULL,
    monto            DECIMAL(6,2) NOT NULL,
    estado           ENUM('pagado','pendiente','rechazado','reembolsado') NOT NULL,
    referencia       VARCHAR(60) DEFAULT NULL,     -- id de transacción de la pasarela
    tarjeta_ultimos4 CHAR(4)     DEFAULT NULL,     -- solo los últimos 4 dígitos, NUNCA el número completo
    creado_en        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_pago_reserva FOREIGN KEY (reserva_id) REFERENCES reservas(id) ON DELETE CASCADE,
    INDEX idx_pago_reserva (reserva_id)
) ENGINE=InnoDB;

-- Mejora 5: calificaciones y reseñas -------------------------
CREATE TABLE IF NOT EXISTS resenas (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    cancha_id     INT NOT NULL,
    usuario_id    INT NOT NULL,
    reserva_id    INT NOT NULL,
    calificacion  TINYINT UNSIGNED NOT NULL,       -- 1 a 5
    comentario    VARCHAR(500) DEFAULT NULL,
    creado_en     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_resena_cancha  FOREIGN KEY (cancha_id)  REFERENCES canchas(id)  ON DELETE CASCADE,
    CONSTRAINT fk_resena_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    CONSTRAINT fk_resena_reserva FOREIGN KEY (reserva_id) REFERENCES reservas(id) ON DELETE CASCADE,
    CONSTRAINT chk_calificacion CHECK (calificacion BETWEEN 1 AND 5),

    -- Una reseña por reserva: no se puede inflar la nota calificando varias veces
    UNIQUE KEY uq_resena_reserva (reserva_id),
    INDEX idx_resena_cancha (cancha_id)
) ENGINE=InnoDB;

-- ⚠ Ejecutar SOLO UNA VEZ (el ALTER falla si la columna ya existe; las tablas de arriba sí son re-ejecutables).
-- Corrección: permitir volver a reservar un horario cuya reserva fue cancelada.
-- (Antes el UNIQUE incluía las canceladas y el horario quedaba bloqueado para siempre.)
ALTER TABLE reservas
    ADD COLUMN slot_activo TINYINT GENERATED ALWAYS AS (IF(estado = 'confirmada', 1, NULL)) STORED,
    DROP INDEX uq_cancha_fecha_horario,
    ADD UNIQUE KEY uq_cancha_fecha_horario (cancha_id, fecha, horario_id, slot_activo);
