/* ═══════════════════════════════════════════════════════
   auth.js  —  CanchaYa
   Lógica de autenticación: login, registro, logout (vía API)
═══════════════════════════════════════════════════════ */

// ── Iniciar sesión ────────────────────────────────────
async function doLogin() {
  const email    = document.getElementById('login-email').value.trim();
  const password = document.getElementById('login-pass').value;

  if (!email || !password) {
    alert('Por favor completa todos los campos.');
    return;
  }

  try {
    const res = await fetch(API_BASE + 'login.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json();

    if (!res.ok) {
      alert(data.error || 'Correo o contraseña incorrectos.');
      return;
    }

    usuarioActual = data.usuario;
    await cargarMisReservas();
    updateNavbar();
    showHome();
  } catch (e) {
    console.error(e);
    alert('No se pudo conectar con el servidor.');
  }
}

// ── Registrar usuario ─────────────────────────────────
async function doRegister() {
  const nombre   = document.getElementById('reg-nombre').value.trim();
  const email    = document.getElementById('reg-email').value.trim();
  const tel      = document.getElementById('reg-tel').value.trim();
  const password = document.getElementById('reg-pass').value;

  if (!nombre || !email || !password) {
    alert('Por favor completa todos los campos obligatorios.');
    return;
  }
  if (password.length < 6) {
    alert('La contraseña debe tener al menos 6 caracteres.');
    return;
  }

  try {
    const res = await fetch(API_BASE + 'registro.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nombre, email, tel, password }),
    });
    const data = await res.json();

    if (!res.ok) {
      alert(data.error || 'No se pudo crear la cuenta.');
      return;
    }

    usuarioActual = data.usuario;
    await cargarMisReservas();
    updateNavbar();
    showHome();
  } catch (e) {
    console.error(e);
    alert('No se pudo conectar con el servidor.');
  }
}

// ── Recuperar contraseña: solicitar enlace ────────────
async function doSolicitarReset() {
  const email = document.getElementById('forgot-email').value.trim();
  const hint  = document.getElementById('forgot-hint');

  if (!email) {
    alert('Por favor ingresa tu correo electrónico.');
    return;
  }

  const btn = document.getElementById('forgot-submit-btn');
  btn.disabled = true;

  try {
    const res  = await fetch(API_BASE + 'solicitar_reset.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email }),
    });
    const data = await res.json();

    // Se muestra el mismo mensaje exista o no el correo (por seguridad).
    hint.textContent = data.mensaje || 'Si el correo está registrado, te enviaremos un enlace para restablecer tu contraseña.';
    hint.classList.add('form-hint-success');
    btn.style.display = 'none';
  } catch (e) {
    console.error(e);
    hint.textContent = 'No se pudo conectar con el servidor. Intenta de nuevo.';
    hint.classList.add('form-hint-error');
    btn.disabled = false;
  }
}

// ── Recuperar contraseña: validar token del enlace ────
async function validarTokenReset(token) {
  const hint = document.getElementById('reset-hint');
  const form = document.getElementById('reset-form');

  if (!token) {
    hint.textContent = 'Enlace inválido.';
    hint.classList.add('form-hint-error');
    return;
  }

  try {
    const res  = await fetch(`${API_BASE}validar_token.php?token=${encodeURIComponent(token)}`);
    const data = await res.json();

    if (data.valido) {
      hint.style.display = 'none';
      form.style.display = 'block';
      form.dataset.token = token;
    } else {
      hint.textContent = data.error || 'El enlace de recuperación no es válido.';
      hint.classList.add('form-hint-error');
    }
  } catch (e) {
    console.error(e);
    hint.textContent = 'No se pudo conectar con el servidor.';
    hint.classList.add('form-hint-error');
  }
}

// ── Recuperar contraseña: guardar la nueva contraseña ─
async function doResetPassword() {
  const token = document.getElementById('reset-form').dataset.token;
  const pass  = document.getElementById('reset-pass').value;
  const pass2 = document.getElementById('reset-pass2').value;

  if (!pass || !pass2) {
    alert('Completa ambos campos.');
    return;
  }
  if (pass.length < 6) {
    alert('La contraseña debe tener al menos 6 caracteres.');
    return;
  }
  if (pass !== pass2) {
    alert('Las contraseñas no coinciden.');
    return;
  }

  try {
    const res  = await fetch(API_BASE + 'reset_password.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token, password: pass }),
    });
    const data = await res.json();

    if (!res.ok) {
      alert(data.error || 'No se pudo actualizar la contraseña.');
      return;
    }

    alert(data.mensaje || 'Tu contraseña fue actualizada. Ya puedes iniciar sesión.');
    showLogin();
  } catch (e) {
    console.error(e);
    alert('No se pudo conectar con el servidor.');
  }
}

// ── Cerrar sesión ─────────────────────────────────────
async function cerrarSesion() {
  if (!confirm('¿Deseas cerrar sesión?')) return;

  try {
    await fetch(API_BASE + 'logout.php');
  } catch (e) {
    console.error(e);
  }

  usuarioActual = null;
  misReservas = [];
  updateNavbar();
  showHome();
}
