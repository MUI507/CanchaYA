/* ═══════════════════════════════════════════════════════
   reservas.js  —  CanchaYa
   Lógica de reservas: booking view, slots, confirmación (vía API)
═══════════════════════════════════════════════════════ */

let selectedSlot   = null;   // texto de la hora seleccionada, ej "14:00"
let selectedCancha = null;
let selectedFecha  = null;   // YYYY-MM-DD — Mejora 3: selector de fecha
let metodoPago     = 'tarjeta'; // Mejora 4: 'tarjeta' | 'yappy' | 'efectivo'

// Formatea "YYYY-MM-DD" a texto legible en español, sin desfase de
// zona horaria (new Date("YYYY-MM-DD") lo interpreta como UTC y puede
// mostrar el día anterior en horarios de Panamá).
function formatFechaLegible(fechaStr, opts) {
  const [y, m, d] = fechaStr.split('-').map(Number);
  return new Date(y, m - 1, d).toLocaleDateString('es-PA', opts);
}

// ── Mostrar vista de reserva ──────────────────────────
async function showBooking(id, fecha = fechaHoy()) {
  selectedCancha = canchas.find(c => c.id === id);
  selectedSlot   = null;
  selectedFecha  = fecha;
  metodoPago     = 'tarjeta';

  await cargarHorariosYOcupados(id, fecha);
  const busy = ocupadosPorCancha[`${id}_${fecha}`] || [];

  hideAllViews();
  document.getElementById('booking-view').style.display = 'block';
  window.scrollTo({ top: 0, behavior: 'smooth' });

  document.getElementById('booking-content').innerHTML = `
    <div class="booking-layout">

      <!-- ── Left panel ── -->
      <div class="booking-left">
        <h2>${selectedCancha.nombre}</h2>
        <p>${selectedCancha.tipo} · ${selectedCancha.zona}</p>

        <div class="info-chips">
          <span class="pill pill-green">${selectedCancha.tipo}</span>
          <span class="pill ${selectedCancha.luz ? 'pill-green' : 'pill-gray'}">
            ${selectedCancha.luz ? '💡 Con iluminación' : 'Sin iluminación'}
          </span>
          <span class="pill ${selectedCancha.techada ? 'pill-green' : 'pill-gray'}">
            ${selectedCancha.techada ? '🏠 Techada' : 'Al aire libre'}
          </span>
        </div>

        <div class="label-section">Elige la fecha</div>
        <div class="form-group" style="max-width:220px;">
          <input type="date" id="f-fecha" value="${fecha}"
            min="${fechaHoy()}" max="${fechaMaxima()}"
            onchange="cambiarFechaBooking(this.value)"/>
        </div>

        <div class="label-section">Selecciona un horario</div>
        <div class="slot-legend">
          <span><span class="dot-avail"></span> Disponible</span>
          <span><span class="dot-busy"></span> Ocupado</span>
          <span><span class="dot-sel"></span> Seleccionado</span>
        </div>
        <div class="slots-grid">
          ${horarios.map(h => `
            <button
              class="slot ${busy.includes(h.id) ? 'busy' : ''}"
              ${busy.includes(h.id) ? 'disabled' : `onclick="selectSlot(this, '${h.hora}')"`}>
              ${h.hora}
            </button>
          `).join('')}
        </div>

        <div class="label-section">Datos del jugador</div>
        <div class="booking-form">
          <div class="form-group">
            <label>Nombre completo</label>
            <input type="text" id="f-nombre"
              value="${usuarioActual ? usuarioActual.nombre : ''}"
              placeholder="Tu nombre completo"/>
          </div>
          <div class="form-group">
            <label>Teléfono</label>
            <input type="tel" id="f-tel"
              value="${usuarioActual ? usuarioActual.tel || '' : ''}"
              placeholder="+507 6000-0000"/>
          </div>
          <div class="form-group">
            <label>Correo electrónico</label>
            <input type="email" id="f-email"
              value="${usuarioActual ? usuarioActual.email : ''}"
              placeholder="correo@ejemplo.com"/>
          </div>
          <div class="form-group">
            <label>Número de jugadores</label>
            <select id="f-jugadores">
              <option value="5">5 jugadores</option>
              <option value="6">6 jugadores</option>
              <option value="7">7 jugadores</option>
              <option value="10">10 jugadores</option>
              <option value="11">11 jugadores</option>
            </select>
          </div>
        </div>

        <div class="label-section">Método de pago</div>
        <div class="pay-methods" role="radiogroup" aria-label="Método de pago">
          <label class="pay-option active" data-metodo="tarjeta">
            <input type="radio" name="metodo-pago" value="tarjeta" checked onchange="elegirMetodoPago('tarjeta')"/>
            <span class="pay-ico">💳</span>Tarjeta
          </label>
          <label class="pay-option" data-metodo="yappy">
            <input type="radio" name="metodo-pago" value="yappy" onchange="elegirMetodoPago('yappy')"/>
            <span class="pay-ico">📱</span>Yappy
          </label>
          <label class="pay-option" data-metodo="efectivo">
            <input type="radio" name="metodo-pago" value="efectivo" onchange="elegirMetodoPago('efectivo')"/>
            <span class="pay-ico">💵</span>Pagar en la cancha
          </label>
        </div>
        <div class="pay-fields" id="pay-fields"></div>

        <div class="reviews-box" id="reviews-box"></div>
      </div>

      <!-- ── Right panel (summary) ── -->
      <div>
        <div class="summary">
          <h3>Resumen de reserva</h3>
          <div class="sum-thumb">${fieldSVG(true)}</div>
          <div class="sum-rows">
            <div class="sum-row">
              <span class="label">Cancha</span>
              <span class="value">${selectedCancha.nombre}</span>
            </div>
            <div class="sum-row">
              <span class="label">Tipo</span>
              <span class="value">${selectedCancha.tipo}</span>
            </div>
            <div class="sum-row">
              <span class="label">Fecha</span>
              <span class="value">${formatFechaLegible(fecha, {weekday:'short', day:'numeric', month:'short'})}</span>
            </div>
            <div class="sum-row">
              <span class="label">Horario</span>
              <span class="value" id="sum-hora">— Selecciona</span>
            </div>
            <div class="sum-row">
              <span class="label">Duración</span>
              <span class="value">1 hora</span>
            </div>
          </div>
          <div class="sum-total">
            <span class="t-label">Total a pagar</span>
            <span class="t-value">$${selectedCancha.precio}</span>
          </div>
          <button class="btn-confirm" id="btn-pagar" onclick="confirmarReserva()">Confirmar reserva</button>
        </div>
      </div>

    </div>`;

  elegirMetodoPago('tarjeta');          // Mejora 4
  cargarResenasCancha(selectedCancha.id); // Mejora 5 (no bloquea la vista)
}

// ── Mejora 4: mostrar los campos según el método de pago ──
function elegirMetodoPago(metodo) {
  metodoPago = metodo;
  document.querySelectorAll('.pay-option').forEach(o =>
    o.classList.toggle('active', o.dataset.metodo === metodo));

  const cont = document.getElementById('pay-fields');
  if (metodo === 'tarjeta') {
    cont.innerHTML = `
      <div class="pay-test">Modo de pruebas: usa la tarjeta <strong>4242 4242 4242 4242</strong> (cualquier fecha futura y CVV). La <strong>4000 0000 0000 0002</strong> simula un rechazo. No se cobra dinero real.</div>
      <div class="booking-form">
        <div class="form-group">
          <label>Número de tarjeta</label>
          <input type="text" id="p-numero" inputmode="numeric" autocomplete="cc-number"
            maxlength="23" placeholder="0000 0000 0000 0000" oninput="formatearTarjeta(this)"/>
        </div>
        <div class="form-group">
          <label>Nombre del titular</label>
          <input type="text" id="p-titular" autocomplete="cc-name" placeholder="Como aparece en la tarjeta"/>
        </div>
        <div class="pay-row">
          <div class="form-group">
            <label>Vence (MM/AA)</label>
            <input type="text" id="p-vence" inputmode="numeric" autocomplete="cc-exp"
              maxlength="5" placeholder="MM/AA" oninput="formatearVence(this)"/>
          </div>
          <div class="form-group">
            <label>CVV</label>
            <input type="password" id="p-cvv" inputmode="numeric" autocomplete="cc-csc"
              maxlength="4" placeholder="•••"/>
          </div>
        </div>
      </div>`;
  } else if (metodo === 'yappy') {
    cont.innerHTML = `
      <div class="booking-form">
        <div class="form-group">
          <label>Celular registrado en Yappy</label>
          <input type="tel" id="p-celular" autocomplete="tel" placeholder="6000-0000"/>
        </div>
      </div>
      <p class="pay-note">Recibirás la solicitud de cobro en tu app de Yappy.</p>`;
  } else {
    cont.innerHTML = `<p class="pay-note">Reservas ahora y pagas directamente en la cancha. Tu horario queda apartado.</p>`;
  }

  const btn = document.getElementById('btn-pagar');
  if (btn) btn.textContent = metodo === 'efectivo'
    ? 'Confirmar reserva'
    : `Pagar $${selectedCancha.precio} y reservar`;
}

// Inserta un espacio cada 4 dígitos mientras se escribe
function formatearTarjeta(el) {
  el.value = el.value.replace(/\D/g, '').slice(0, 19).replace(/(\d{4})(?=\d)/g, '$1 ');
}
// Inserta la "/" automáticamente: 1230 → 12/30
function formatearVence(el) {
  const d = el.value.replace(/\D/g, '').slice(0, 4);
  el.value = d.length > 2 ? d.slice(0, 2) + '/' + d.slice(2) : d;
}

// Arma el objeto "pago" que viaja al servidor (solo en la petición, nunca se guarda en el front)
function datosDePago() {
  if (metodoPago === 'tarjeta') {
    return {
      numero:  document.getElementById('p-numero')?.value || '',
      titular: document.getElementById('p-titular')?.value.trim() || '',
      vence:   document.getElementById('p-vence')?.value || '',
      cvv:     document.getElementById('p-cvv')?.value || '',
    };
  }
  if (metodoPago === 'yappy') {
    return { celular: document.getElementById('p-celular')?.value || '' };
  }
  return {};
}

// ── Cambiar la fecha dentro de la vista de reserva ────
async function cambiarFechaBooking(nuevaFecha) {
  if (!nuevaFecha || !selectedCancha) return;
  await showBooking(selectedCancha.id, nuevaFecha);
}

// ── Seleccionar horario ───────────────────────────────
function selectSlot(el, hora) {
  document.querySelectorAll('.slot').forEach(s => s.classList.remove('selected'));
  el.classList.add('selected');
  selectedSlot = hora;
  const sumHora = document.getElementById('sum-hora');
  if (sumHora) sumHora.textContent = hora;
}

// ── Confirmar reserva ─────────────────────────────────
async function confirmarReserva() {
  if (!selectedSlot) {
    alert('Por favor selecciona un horario antes de confirmar.');
    return;
  }

  const nombre    = document.getElementById('f-nombre')?.value.trim();
  const email     = document.getElementById('f-email')?.value.trim();
  const tel       = document.getElementById('f-tel')?.value.trim();
  const jugadores = document.getElementById('f-jugadores')?.value;

  if (!nombre) { alert('Por favor ingresa tu nombre.'); return; }
  if (!email)  { alert('Por favor ingresa tu correo.'); return; }

  const btn = document.getElementById('btn-pagar');
  const textoBtn = btn ? btn.textContent : 'Confirmar reserva';
  if (btn) { btn.disabled = true; btn.textContent = 'Procesando...'; }

  try {
    const res = await fetch(`${API_BASE}crear_reserva.php`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        cancha_id: selectedCancha.id,
        horario:   selectedSlot,
        fecha:     selectedFecha,
        nombre, tel, email, jugadores,
        metodo_pago: metodoPago,
        pago:        datosDePago(),
      }),
    });
    const data = await res.json();

    if (!res.ok) {
      alert(data.error || 'No se pudo confirmar la reserva.');
      if (btn) { btn.disabled = false; btn.textContent = textoBtn; }
      // Pago rechazado / datos inválidos: se queda en la vista para corregir sin reescribir todo.
      // Solo si el horario ya fue tomado (409) se recarga la disponibilidad.
      if (res.status === 409) await showBooking(selectedCancha.id, selectedFecha);
      return;
    }

    // Mostrar pantalla de éxito
    hideAllViews();
    document.getElementById('success-view').style.display = 'block';
    document.getElementById('success-detail-card').innerHTML = `
      <div class="sc-row"><span class="sc-label">Cancha</span><span class="sc-value">${selectedCancha.nombre}</span></div>
      <div class="sc-row"><span class="sc-label">Tipo</span><span class="sc-value">${selectedCancha.tipo}</span></div>
      <div class="sc-row"><span class="sc-label">Fecha</span><span class="sc-value">${formatFechaLegible(selectedFecha, { weekday:'long', day:'numeric', month:'long' })}</span></div>
      <div class="sc-row"><span class="sc-label">Horario</span><span class="sc-value">${selectedSlot}</span></div>
      <div class="sc-row"><span class="sc-label">Jugador</span><span class="sc-value">${nombre}</span></div>
      <div class="sc-row"><span class="sc-label">Jugadores</span><span class="sc-value">${jugadores}</span></div>
      <div class="sc-row"><span class="sc-label">Total</span><span class="sc-value">$${selectedCancha.precio}</span></div>
      <div class="sc-row"><span class="sc-label">Pago</span><span class="sc-value">${
        data.pago_estado === 'pagado'
          ? `✓ Pagado con ${metodoPago === 'yappy' ? 'Yappy' : 'tarjeta'}${data.referencia ? ' · Ref. ' + esc(data.referencia) : ''}`
          : 'Pendiente — pagas en la cancha'
      }</span></div>
    `;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  } catch (e) {
    console.error(e);
    alert('No se pudo conectar con el servidor.');
    if (btn) { btn.disabled = false; btn.textContent = textoBtn; }
  }
}

// ── Cancelar reserva ──────────────────────────────────
async function cancelarReserva(reservaId) {
  const reserva = misReservas.find(r => r.id === reservaId);
  if (!reserva) return;

  if (!confirm(`¿Cancelar tu reserva en ${reserva.cancha} a las ${reserva.horario}?`)) return;

  try {
    const res = await fetch(`${API_BASE}cancelar_reserva.php`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ reserva_id: reservaId }),
    });
    if (!res.ok) {
      alert('No se pudo cancelar la reserva.');
      return;
    }
  } catch (e) {
    console.error(e);
    alert('No se pudo conectar con el servidor.');
    return;
  }

  await cargarMisReservas();
  renderMisReservas();
}
