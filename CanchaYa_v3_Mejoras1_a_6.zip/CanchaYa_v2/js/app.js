/* ═══════════════════════════════════════════════════════
   app.js  —  CanchaYa
   Inicialización de la aplicación
═══════════════════════════════════════════════════════ */

document.addEventListener('DOMContentLoaded', async () => {
  const grid = document.getElementById('canchas-grid');
  if (grid) grid.innerHTML = `<div class="empty-state" style="grid-column:1/-1"><p>Cargando canchas...</p></div>`;

  await Promise.all([cargarCanchas(), restaurarSesion()]);

  if (usuarioActual) await cargarMisReservas();

  renderCanchas(canchas);
  updateNavbar();

  // Si el usuario llegó desde el enlace de un correo de recuperación
  // (index.html?reset_token=...), se muestra directamente esa vista.
  const params    = new URLSearchParams(window.location.search);
  const resetToken = params.get('reset_token');
  if (resetToken) {
    showResetPassword(resetToken);
  }

  const searchInput = document.getElementById('search-input');
  if (searchInput) {
    searchInput.addEventListener('keydown', e => {
      if (e.key === 'Enter') buscarCanchas();
    });
  }
});
