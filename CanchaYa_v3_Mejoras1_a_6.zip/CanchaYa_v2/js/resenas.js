/* ═══════════════════════════════════════════════════════
   resenas.js  —  CanchaYa  (Mejora 5: calificaciones y reseñas)
   · cargarResenasCancha(): lista + promedio en la vista de reserva
   · abrirFormResena() / enviarResena(): calificar desde "Mis reservas"
═══════════════════════════════════════════════════════ */

// ── Reseñas de una cancha (se pintan dentro de #reviews-box) ──
async function cargarResenasCancha(canchaId) {
  const box = document.getElementById('reviews-box');
  if (!box) return;

  try {
    const res  = await fetch(`${API_BASE}resenas_listar.php?cancha_id=${canchaId}`);
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Error');

    // Si el usuario ya cambió de cancha mientras cargaba, no pisar la vista
    if (!selectedCancha || selectedCancha.id !== canchaId) return;

    if (!data.total) {
      box.innerHTML = `<div class="label-section">Reseñas</div>
        <p class="review-empty">Aún no hay reseñas. ¡Sé el primero en calificar esta cancha después de jugar!</p>`;
      return;
    }

    box.innerHTML = `
      <div class="label-section">Reseñas</div>
      <div class="review-summary">
        <span class="review-avg">${data.promedio.toFixed(1)}</span>
        <div>${estrellasHTML(data.promedio)}<div class="review-date">${data.total} reseña${data.total === 1 ? '' : 's'}</div></div>
      </div>
      ${data.resenas.map(r => `
        <div class="review-item">
          <div class="review-head">
            <span><strong>${esc(r.autor)}</strong> ${estrellasHTML(r.calificacion)}</span>
            <span class="review-date">${esc(r.creado_en.slice(0, 10))}</span>
          </div>
          ${r.comentario ? `<p class="review-text">${esc(r.comentario)}</p>` : ''}
        </div>
      `).join('')}`;
  } catch (e) {
    console.error('Error al cargar reseñas:', e);
    box.innerHTML = '';
  }
}

// ── Formulario de calificación dentro de la tarjeta de la reserva ──
function abrirFormResena(reservaId) {
  const cont = document.getElementById(`resena-form-${reservaId}`);
  if (!cont) return;
  if (cont.innerHTML.trim()) { cont.innerHTML = ''; return; }   // segundo clic = cerrar

  // Las estrellas van en orden inverso (5→1) para poder iluminar con CSS puro
  cont.innerHTML = `
    <div class="review-form">
      <div class="star-input">
        ${[5, 4, 3, 2, 1].map(n => `
          <input type="radio" name="estrellas-${reservaId}" id="st-${reservaId}-${n}" value="${n}"/>
          <label for="st-${reservaId}-${n}" title="${n} estrella${n === 1 ? '' : 's'}">★</label>
        `).join('')}
      </div>
      <textarea id="resena-texto-${reservaId}" maxlength="500"
        placeholder="Cuéntanos cómo estuvo la cancha (opcional)"></textarea>
      <button class="btn-resena" id="resena-btn-${reservaId}" onclick="enviarResena(${reservaId})">Enviar reseña</button>
    </div>`;
}

async function enviarResena(reservaId) {
  const marcada = document.querySelector(`input[name="estrellas-${reservaId}"]:checked`);
  if (!marcada) { alert('Elige de 1 a 5 estrellas.'); return; }

  const comentario = document.getElementById(`resena-texto-${reservaId}`).value.trim();
  const btn = document.getElementById(`resena-btn-${reservaId}`);
  btn.disabled = true;
  btn.textContent = 'Enviando...';

  try {
    const res = await fetch(`${API_BASE}resenas_crear.php`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ reserva_id: reservaId, calificacion: Number(marcada.value), comentario }),
    });
    const data = await res.json();
    if (!res.ok) {
      alert(data.error || 'No se pudo guardar la reseña.');
      btn.disabled = false;
      btn.textContent = 'Enviar reseña';
      return;
    }
  } catch (e) {
    console.error(e);
    alert('No se pudo conectar con el servidor.');
    btn.disabled = false;
    btn.textContent = 'Enviar reseña';
    return;
  }

  // Refrescar: tarjeta de la reserva y promedios del catálogo
  await Promise.all([cargarMisReservas(), cargarCanchas()]);
  renderMisReservas();
}
