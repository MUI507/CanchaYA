# Mejora 1 — Recuperación de contraseña por correo electrónico

Implementación del flujo propuesto en la diapositiva 8 de la presentación:
1. El usuario da clic en "¿Olvidaste tu contraseña?" (en el login).
2. Ingresa su correo registrado.
3. El sistema genera un token único que expira en 30 minutos.
4. Se envía un enlace de restablecimiento por correo.
5. El usuario define una nueva contraseña; el token se anula.

## Archivos nuevos

| Archivo | Descripción |
|---|---|
| `mejora1_password_resets.sql` | Migración: crea la tabla `password_resets` sin tocar el resto de la BD |
| `config.php` | URL del sitio y configuración SMTP |
| `api/mailer.php` | Helper de envío de correo (SMTP si está configurado, si no `mail()`, si no un log local) |
| `api/solicitar_reset.php` | Paso 1: recibe el correo, genera el token y envía el enlace |
| `api/validar_token.php` | Verifica que el token del enlace sea válido, no usado y no expirado |
| `api/reset_password.php` | Paso final: guarda la nueva contraseña y anula el token |

## Archivos modificados

- `canchaya_bd.sql` — se agregó la tabla `password_resets` (si vas a montar la BD desde cero, ya no necesitas correr la migración aparte)
- `index.html` — enlace "¿Olvidaste tu contraseña?" + 2 vistas nuevas (`forgot-view`, `reset-view`)
- `js/ui.js` — `showForgotPassword()`, `showResetPassword()`
- `js/auth.js` — `doSolicitarReset()`, `validarTokenReset()`, `doResetPassword()`
- `js/app.js` — detecta `?reset_token=...` en la URL al cargar la página y abre la vista correspondiente
- `css/styles.css` — clase `.form-hint` para los mensajes de estado del formulario

## Cómo instalar

**Si es un proyecto nuevo (BD desde cero):** simplemente corre `canchaya_bd.sql`, ya incluye la tabla nueva.

**Si tu BD ya existe (con datos que no quieres perder):** corre solo la migración:
```sql
SOURCE mejora1_password_resets.sql;
```

## Cómo configurar el envío de correo

Edita `config.php`:

- **`SITE_URL`**: ajústalo a donde sirvas el proyecto (ej. `http://localhost/CANCHA-YA`).
- **SMTP (recomendado)**: instala PHPMailer con Composer (`composer require phpmailer/phpmailer`) y llena `SMTP_HOST`, `SMTP_USER`, `SMTP_PASS`, etc. Con Gmail necesitas una "contraseña de aplicación" (no la contraseña normal de la cuenta).
- **Sin SMTP configurado**: el sistema intenta `mail()` nativa de PHP, y si tampoco está disponible (lo más común en XAMPP local sin configurar), registra el correo completo —incluyendo el enlace— en `logs/emails.log`. Esto permite probar todo el flujo sin tener un servidor de correo real.

## Cómo probar

1. Ve a **Iniciar sesión → ¿Olvidaste tu contraseña?**
2. Ingresa un correo que exista en `usuarios` (ej. `admin@canchaya.com`).
3. Revisa `logs/emails.log` (o tu bandeja de entrada si configuraste SMTP) y copia el enlace.
4. Ábrelo — la app detecta `?reset_token=...` en la URL y muestra el formulario de nueva contraseña.
5. Define la nueva contraseña e inicia sesión con ella.

## Decisiones de diseño (para el sustento ante la profesora)

- **El mensaje de respuesta es siempre el mismo**, exista o no el correo en la base de datos. Es una práctica estándar de seguridad: evita que alguien use el formulario para averiguar qué correos están registrados en el sistema.
- **El token es de un solo uso** (`usado = 1` tras cambiarlo) y expira a los 30 minutos, como pide la diapositiva 8.
- Al pedir un nuevo enlace, **se invalidan los tokens anteriores** del mismo usuario, para que solo el más reciente sea válido.

---

# Mejora 2 — Notificaciones por correo al confirmar/cancelar reserva

Cada vez que una reserva se crea o se cancela (desde el sitio del cliente o
desde el panel de administración), se envía automáticamente un correo con
los detalles (cancha, zona, fecha, hora, jugadores, precio).

## Archivos modificados

- `api/mailer.php` — se agregó `notificar_reserva($pdo, $reservaId, $tipo)`, que arma y envía el correo según el tipo (`'confirmada'` o `'cancelada'`). Reutiliza `enviar_correo()` de la Mejora 1, así que usa la misma configuración de `config.php`.
- `api/crear_reserva.php` — notifica `'confirmada'` justo después de guardar la reserva
- `api/cancelar_reserva.php` — notifica `'cancelada'` cuando el cliente cancela desde "Mis reservas"
- `api/admin/reservas_cancelar.php` — notifica `'cancelada'` cuando el admin cancela desde el panel

## Decisiones de diseño

- El envío de correo va dentro de un `try/catch`: **si falla el correo, la reserva o cancelación igual se completa** (la app no debe romperse por un problema de SMTP). El error queda registrado con `error_log()`.
- Se reutiliza el mismo `mailer.php` de la Mejora 1 — no hay configuración adicional que hacer, ni tablas nuevas.
- Si no configuraste SMTP, los correos de reservas también caen en `logs/emails.log`, igual que los de recuperación de contraseña.

## Cómo probar

1. Haz una reserva normal desde la página principal.
2. Revisa `logs/emails.log` (o tu correo, si configuraste SMTP) — debe aparecer el correo de confirmación con los datos de la reserva.
3. Cancélala desde "Mis reservas" (o desde el panel de administración).
4. Revisa de nuevo el log/correo — debe aparecer el correo de cancelación.

---

# Mejora 3 — Selector de fecha para reservar con anticipación

Antes, toda reserva se hacía forzosamente para el día de hoy (`fechaHoy()`
estaba fijo en el frontend). Ahora se puede elegir cualquier fecha entre
hoy y los próximos 30 días.

El backend (`get_horarios.php`) **ya recibía y usaba el parámetro `fecha`**,
así que el trabajo fue principalmente en el frontend, más una validación
de refuerzo en el backend.

## Archivos modificados

- `js/data.js` — `cargarHorariosYOcupados(canchaId, fecha)` ahora recibe la fecha y cachea la disponibilidad por `cancha+fecha` (antes se cacheaba solo por cancha, lo que habría mezclado la disponibilidad de distintos días); se agregó `fechaMaxima()` (hoy + 30 días)
- `js/reservas.js` — nuevo `<input type="date">` en la vista de reserva, función `cambiarFechaBooking()` para recargar horarios al cambiar la fecha, y `selectedFecha` reemplaza los usos de "hoy" fijo en el resumen, la confirmación y la pantalla de éxito
- `api/crear_reserva.php` — valida que la fecha no sea pasada ni supere los 30 días de anticipación (por si alguien llama a la API directamente, sin pasar por el selector)

## Cómo probar

1. Entra a cualquier cancha ("Reservar ahora").
2. Verás el nuevo selector de fecha arriba de los horarios, con hoy seleccionado por defecto.
3. Cambia la fecha — los horarios disponibles/ocupados se recargan según ese día.
4. Confirma la reserva: el resumen y la pantalla final deben mostrar la fecha elegida (no la de hoy).
5. Revisa "Mis reservas": debe aparecer con la fecha correcta.


---

# Mejoras 4, 5 y 6 (Pagos, Reseñas, Reportes + SMS)

## Instalación
1. Base de datos nueva: importa `canchaya_bd.sql` (ya incluye todo).
2. Base de datos existente: ejecuta **una sola vez** `mejora4_5_6.sql` (conserva tus datos).
3. No hace falta instalar nada más (PHP + MySQL/MariaDB como antes).

## Mejora 4 — Pagos en línea (tarjeta / Yappy)
- En la vista de reserva se elige: **Tarjeta**, **Yappy** o **Pagar en la cancha**.
- `PAGOS_MODO = 'simulado'` en `config.php`: no se mueve dinero real.
  - Tarjeta de prueba aprobada: `4242 4242 4242 4242` (fecha futura, cualquier CVV).
  - Tarjeta de prueba rechazada: `4000 0000 0000 0002`.
  - Yappy: cualquier celular panameño válido (8 dígitos, empieza con 6).
- La reserva y el cobro van en una transacción: si el pago falla, el horario queda libre.
- Se guarda solo método, monto, estado, referencia y los últimos 4 dígitos. Nunca el número completo ni el CVV.
- Al cancelar una reserva pagada, el pago pasa a `reembolsado`.
- **Para producción:** contratar una pasarela y completar `cobrar_tarjeta_real()` y `cobrar_yappy_real()` en `api/pagos.php` (hoy fallan de forma explícita). Con pasarela real, usar su formulario/tokenización para que la tarjeta no pase por tu servidor.

## Mejora 5 — Calificaciones y reseñas
- Tabla `resenas`: 1–5 estrellas + comentario (máx. 500). Una reseña por reserva.
- Solo el dueño de una reserva **ya jugada** puede calificar (desde "Mis reservas").
- El promedio se ve en el catálogo y las reseñas en la vista de la cancha (solo primer nombre del autor).
- Los comentarios se escapan al mostrarse (sin XSS).

## Mejora 6 — Reportes exportables + SMS
- Panel admin → pestaña **Reportes**: filtros por fecha y cancha, ingresos totales, cobrado en línea vs por cobrar, ticket promedio, barras por día y tabla por cancha.
- **Exportar CSV** (abre directo en Excel, con tildes). Endpoint: `api/admin/reporte_ingresos.php` (`?formato=csv`).
- SMS: `enviar_sms()` en `api/mailer.php`. Con credenciales de Twilio en `config.php` envía SMS reales; sin ellas, escribe en `logs/sms.log`.

## Correcciones incluidas
- Un horario cancelado ya se puede volver a reservar (antes quedaba bloqueado).
- Cancelar una reserva exige ser el dueño o admin, y no permite cancelar reservas ya jugadas (salvo admin).
- `logs/emails.log` ahora conserva el enlace de recuperación de contraseña (antes lo borraba).

## Pendientes conocidos
- `api/mis_reservas.php` aún acepta `?email=` sin sesión (permite ver reservas ajenas). Recomendado quitarlo.
- Las cifras del inicio (24 canchas, 1.2K reservas, 4.8★) están escritas a mano.
- En el CSV, los teléfonos que empiezan con `+` llevan un apóstrofo (protección contra fórmulas de Excel).
