<?php
/* ═══════════════════════════════════════════════════════
   mailer.php — CanchaYa
   Envío de correos (recuperación de contraseña, notificaciones)

   Estrategia:
     1. Si existe vendor/autoload.php (PHPMailer instalado vía Composer)
        y SMTP_HOST está configurado en config.php → envía por SMTP.
     2. Si no, intenta con la función mail() nativa de PHP.
     3. Si tampoco hay mail() configurado (caso típico en XAMPP local
        sin servidor SMTP), registra el correo en /logs/emails.log
        para poder revisar el enlace/token durante el desarrollo,
        y devuelve true para no romper el flujo de la app.
═══════════════════════════════════════════════════════ */

require_once __DIR__ . '/../config.php';

/**
 * Envía un correo en HTML.
 *
 * @param string $to      Correo destino
 * @param string $subject Asunto
 * @param string $htmlBody Cuerpo en HTML
 * @return bool true si se envió (o se registró en el log de respaldo)
 */
function enviar_correo(string $to, string $subject, string $htmlBody): bool
{
    // ── Opción 1: PHPMailer vía SMTP (recomendado para producción) ──
    $autoload = __DIR__ . '/../vendor/autoload.php';
    if (SMTP_HOST !== '' && file_exists($autoload)) {
        require_once $autoload;

        try {
            $mail = new PHPMailer\PHPMailer\PHPMailer(true);
            $mail->isSMTP();
            $mail->Host       = SMTP_HOST;
            $mail->SMTPAuth   = true;
            $mail->Username   = SMTP_USER;
            $mail->Password   = SMTP_PASS;
            $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port       = SMTP_PORT;
            $mail->CharSet    = 'UTF-8';

            $mail->setFrom(SMTP_FROM_EMAIL, SMTP_FROM_NAME);
            $mail->addAddress($to);
            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body    = $htmlBody;

            $mail->send();
            return true;
        } catch (\Throwable $e) {
            error_log('Error enviando correo (SMTP): ' . $e->getMessage());
            // Si falla el SMTP, cae al respaldo de log para no perder el flujo.
        }
    }

    // ── Opción 2: mail() nativa de PHP ──────────────────────────────
    if (function_exists('mail')) {
        $headers  = "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
        $headers .= 'From: ' . SMTP_FROM_NAME . ' <' . SMTP_FROM_EMAIL . ">\r\n";

        // @ para evitar que un mail() mal configurado (típico en XAMPP
        // local sin sendmail) interrumpa la respuesta con un warning.
        if (@mail($to, $subject, $htmlBody, $headers)) {
            return true;
        }
    }

    // ── Opción 3: respaldo — registrar el correo en un log local ───
    // Útil en desarrollo (XAMPP sin SMTP configurado): permite ver el
    // enlace de restablecimiento sin necesidad de un correo real.
    $logDir = __DIR__ . '/../logs';
    if (!is_dir($logDir)) {
        mkdir($logDir, 0777, true);
    }

    $entry  = "\n" . str_repeat('─', 60) . "\n";
    $entry .= '[' . date('Y-m-d H:i:s') . "] Para: $to\n";
    $entry .= "Asunto: $subject\n\n";
    // Conserva la URL de los enlaces: strip_tags() borraría el href y el
    // enlace de recuperación nunca aparecería en el log.
    $texto  = preg_replace('/<a\s[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)<\/a>/is', '$2: $1', $htmlBody);
    $entry .= strip_tags(str_replace(['<br>', '<br/>', '<br />'], "\n", $texto)) . "\n";

    file_put_contents($logDir . '/emails.log', $entry, FILE_APPEND);

    return true;
}

/**
 * Envía un SMS (Mejora 2 ampliada: "correo o SMS").
 * Usa la API REST de Twilio si TWILIO_SID/TOKEN/FROM están configurados;
 * si no, registra el mensaje en logs/sms.log (útil para pruebas locales).
 *
 * @param string $telefono Teléfono tal como lo escribió el usuario (ej "+507 6111-1111" o "6111-1111")
 */
function enviar_sms(string $telefono, string $mensaje): bool
{
    // Normalizar a formato E.164: +507XXXXXXXX
    $digitos = preg_replace('/\D/', '', $telefono);
    if ($digitos === '') return false;
    if (strlen($digitos) === 8) $digitos = '507' . $digitos;   // celular panameño sin código de país
    $destino = '+' . $digitos;

    if (TWILIO_SID !== '' && TWILIO_TOKEN !== '' && TWILIO_FROM !== '' && function_exists('curl_init')) {
        $ch = curl_init('https://api.twilio.com/2010-04-01/Accounts/' . TWILIO_SID . '/Messages.json');
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_USERPWD        => TWILIO_SID . ':' . TWILIO_TOKEN,
            CURLOPT_POSTFIELDS     => http_build_query(['To' => $destino, 'From' => TWILIO_FROM, 'Body' => $mensaje]),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 10,
        ]);
        $resp = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($code >= 200 && $code < 300) return true;
        error_log("Error enviando SMS (Twilio, HTTP $code): " . substr((string)$resp, 0, 200));
        // Si falla, cae al log de respaldo
    }

    $logDir = __DIR__ . '/../logs';
    if (!is_dir($logDir)) mkdir($logDir, 0777, true);
    file_put_contents(
        $logDir . '/sms.log',
        '[' . date('Y-m-d H:i:s') . "] Para: $destino\n$mensaje\n" . str_repeat('─', 40) . "\n",
        FILE_APPEND
    );
    return true;
}

/**
 * Envía el correo de notificación de una reserva (Mejora 2).
 *
 * @param PDO    $pdo       Conexión activa
 * @param int    $reservaId Id de la reserva ya guardada en la BD
 * @param string $tipo      'confirmada' | 'cancelada'
 * @return bool
 */
function notificar_reserva(PDO $pdo, int $reservaId, string $tipo): bool
{
    $stmt = $pdo->prepare("
        SELECT r.nombre_jugador, r.email, r.telefono, r.fecha, r.jugadores, r.precio_pagado,
               c.nombre AS cancha, c.zona, h.hora
        FROM reservas r
        JOIN canchas  c ON c.id = r.cancha_id
        JOIN horarios h ON h.id = r.horario_id
        WHERE r.id = ?
    ");
    $stmt->execute([$reservaId]);
    $r = $stmt->fetch();

    // Mejora 4: estado del pago para mencionarlo en el mensaje
    $stmt = $pdo->prepare("SELECT metodo, estado FROM pagos WHERE reserva_id = ? ORDER BY id DESC LIMIT 1");
    $stmt->execute([$reservaId]);
    $pago = $stmt->fetch();

    if (!$r || !$r['email']) {
        return false; // No hay a quién notificar
    }

    $fechaFmt = date('d/m/Y', strtotime($r['fecha']));
    $horaFmt  = substr($r['hora'], 0, 5);

    if ($tipo === 'confirmada') {
        $asunto = 'Reserva confirmada — CanchaYa';
        $intro  = '¡Tu reserva fue confirmada! Estos son los detalles:';
        $pie    = 'Te esperamos. Si necesitas cancelar, puedes hacerlo desde "Mis reservas".';
    } else {
        $asunto = 'Reserva cancelada — CanchaYa';
        $intro  = 'Tu reserva fue cancelada. Estos son los detalles:';
        $pie    = 'Si fue un error, puedes crear una nueva reserva desde la página principal.';
    }

    $lineaPago = '';
    if ($pago) {
        $textos = [
            'pagado'      => 'Pagado en línea (' . $pago['metodo'] . ')',
            'pendiente'   => 'Pendiente: pagas en la cancha',
            'reembolsado' => 'Reembolsado a tu medio de pago',
            'rechazado'   => 'Rechazado',
        ];
        $lineaPago = '<li><strong>Pago:</strong> ' . htmlspecialchars($textos[$pago['estado']] ?? $pago['estado']) . '</li>';
    }

    $cuerpo = "
        <p>Hola " . htmlspecialchars($r['nombre_jugador']) . ",</p>
        <p>$intro</p>
        <ul>
            <li><strong>Cancha:</strong> " . htmlspecialchars($r['cancha']) . " (" . htmlspecialchars($r['zona']) . ")</li>
            <li><strong>Fecha:</strong> $fechaFmt</li>
            <li><strong>Hora:</strong> $horaFmt</li>
            <li><strong>Jugadores:</strong> " . (int)$r['jugadores'] . "</li>
            <li><strong>Precio:</strong> \$" . number_format((float)$r['precio_pagado'], 2) . "</li>
            $lineaPago
        </ul>
        <p>$pie</p>
        <p>— El equipo de CanchaYa</p>
    ";

    $okCorreo = enviar_correo($r['email'], $asunto, $cuerpo);

    // SMS corto si la reserva tiene teléfono (el correo ya salió, un fallo aquí no lo afecta)
    if (!empty($r['telefono'])) {
        try {
            $verbo = $tipo === 'confirmada' ? 'confirmada' : 'cancelada';
            enviar_sms($r['telefono'], "CanchaYa: reserva $verbo — {$r['cancha']}, $fechaFmt a las $horaFmt.");
        } catch (\Throwable $e) {
            error_log('No se pudo enviar el SMS: ' . $e->getMessage());
        }
    }

    return $okCorreo;
}
