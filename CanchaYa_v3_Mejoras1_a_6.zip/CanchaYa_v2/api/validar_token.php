<?php
/* ═══════════════════════════════════════════════════════
   validar_token.php — Mejora 1: Recuperación de contraseña
   Verifica si un token de restablecimiento es válido
   (existe, no fue usado y no expiró) antes de mostrar
   el formulario de nueva contraseña.
═══════════════════════════════════════════════════════ */

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../conexion.php';

$token = trim($_GET['token'] ?? '');

if (!$token) {
    http_response_code(400);
    die(json_encode(['valido' => false, 'error' => 'Token no proporcionado.']));
}

$stmt = $pdo->prepare(
    'SELECT pr.id, pr.expira_en, pr.usado, u.email
     FROM password_resets pr
     JOIN usuarios u ON u.id = pr.usuario_id
     WHERE pr.token = ?'
);
$stmt->execute([$token]);
$reset = $stmt->fetch();

if (!$reset) {
    echo json_encode(['valido' => false, 'error' => 'El enlace de recuperación no es válido.']);
    exit;
}

if ((int)$reset['usado'] === 1) {
    echo json_encode(['valido' => false, 'error' => 'Este enlace ya fue utilizado.']);
    exit;
}

if (strtotime($reset['expira_en']) < time()) {
    echo json_encode(['valido' => false, 'error' => 'El enlace ha expirado. Solicita uno nuevo.']);
    exit;
}

echo json_encode(['valido' => true, 'email' => $reset['email']]);
