<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../conexion.php';
require_once __DIR__ . '/../config.php';   // zona horaria de Panamá
session_start();

$email = $_SESSION['usuario']['email'] ?? ($_GET['email'] ?? null);
if (!$email) {
    http_response_code(401);
    die(json_encode(['error' => 'Debes iniciar sesión.']));
}

// Mejora 4: método/estado del pago · Mejora 5: si ya fue calificada
$stmt = $pdo->prepare("
    SELECT r.id, r.cancha_id, c.nombre AS cancha, c.tipo, c.zona, r.fecha, h.hora AS horario,
           r.nombre_jugador, r.jugadores, r.precio_pagado, r.estado,
           p.metodo AS pago_metodo, p.estado AS pago_estado,
           rs.calificacion AS mi_calificacion
    FROM reservas r
    JOIN canchas  c ON c.id = r.cancha_id
    JOIN horarios h ON h.id = r.horario_id
    LEFT JOIN pagos   p  ON p.reserva_id  = r.id
    LEFT JOIN resenas rs ON rs.reserva_id = r.id
    WHERE r.email = ? AND r.estado = 'confirmada'
    ORDER BY r.fecha DESC, h.hora DESC
");
$stmt->execute([$email]);
$reservas = $stmt->fetchAll();

// "jugada" = la hora de inicio ya pasó → se puede calificar y ya no se puede cancelar
$ahora = ahora_panama();
foreach ($reservas as &$r) {
    $r['jugada']          = fecha_hora_panama($r['fecha'], $r['horario']) <= $ahora;
    $r['mi_calificacion'] = $r['mi_calificacion'] !== null ? (int)$r['mi_calificacion'] : null;
}

echo json_encode($reservas);
