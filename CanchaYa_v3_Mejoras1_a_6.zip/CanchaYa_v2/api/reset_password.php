<?php
/* ═══════════════════════════════════════════════════════
   reset_password.php — Mejora 1: Recuperación de contraseña
   Paso final: valida el token y guarda la nueva contraseña.
   El token se anula (usado = 1) para que no pueda reutilizarse.
═══════════════════════════════════════════════════════ */

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../conexion.php';

$data     = json_decode(file_get_contents('php://input'), true);
$token    = trim($data['token'] ?? '');
$password = $data['password'] ?? '';

if (!$token || !$password) {
    http_response_code(400);
    die(json_encode(['error' => 'Faltan datos obligatorios.']));
}
if (strlen($password) < 6) {
    http_response_code(400);
    die(json_encode(['error' => 'La contraseña debe tener al menos 6 caracteres.']));
}

$stmt = $pdo->prepare('SELECT id, usuario_id, expira_en, usado FROM password_resets WHERE token = ?');
$stmt->execute([$token]);
$reset = $stmt->fetch();

if (!$reset) {
    http_response_code(404);
    die(json_encode(['error' => 'El enlace de recuperación no es válido.']));
}
if ((int)$reset['usado'] === 1) {
    http_response_code(410);
    die(json_encode(['error' => 'Este enlace ya fue utilizado.']));
}
if (strtotime($reset['expira_en']) < time()) {
    http_response_code(410);
    die(json_encode(['error' => 'El enlace ha expirado. Solicita uno nuevo.']));
}

$hash = password_hash($password, PASSWORD_BCRYPT);

$pdo->beginTransaction();
try {
    $pdo->prepare('UPDATE usuarios SET password = ? WHERE id = ?')
        ->execute([$hash, $reset['usuario_id']]);

    // Anula este token y cualquier otro token pendiente del mismo usuario.
    $pdo->prepare('UPDATE password_resets SET usado = 1 WHERE usuario_id = ?')
        ->execute([$reset['usuario_id']]);

    $pdo->commit();
} catch (PDOException $e) {
    $pdo->rollBack();
    http_response_code(500);
    die(json_encode(['error' => 'No se pudo actualizar la contraseña.']));
}

echo json_encode(['ok' => true, 'mensaje' => 'Tu contraseña fue actualizada. Ya puedes iniciar sesión.']);
