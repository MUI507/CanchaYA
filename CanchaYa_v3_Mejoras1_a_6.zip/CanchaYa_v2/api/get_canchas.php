<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../conexion.php';

// Mejora 5: cada cancha incluye su calificación promedio y el número de reseñas
$stmt = $pdo->query("
    SELECT c.id, c.nombre, c.tipo, c.zona, c.precio, c.luz, c.techada,
           COALESCE(ROUND(AVG(r.calificacion), 1), 0) AS promedio,
           COUNT(r.id) AS total_resenas
    FROM canchas c
    LEFT JOIN resenas r ON r.cancha_id = c.id
    WHERE c.activa = 1
    GROUP BY c.id
    ORDER BY c.id
");
$canchas = $stmt->fetchAll();

// Convertir 0/1 a boolean para que coincida con el front (luz:true, techada:false)
foreach ($canchas as &$c) {
    $c['luz']           = (bool) $c['luz'];
    $c['techada']       = (bool) $c['techada'];
    $c['precio']        = (float) $c['precio'];
    $c['promedio']      = (float) $c['promedio'];
    $c['total_resenas'] = (int) $c['total_resenas'];
}

echo json_encode($canchas);
