<?php
/* ═══════════════════════════════════════════════════════
   reporte_ingresos.php — Mejora 6: reportes de ingresos exportables
   GET ?desde=YYYY-MM-DD&hasta=YYYY-MM-DD[&cancha_id=N][&formato=csv]
   · Sin "formato": devuelve JSON (resumen + por día + por cancha + detalle)
   · formato=csv : descarga el detalle como CSV (abre directo en Excel)
   Los ingresos cuentan reservas CONFIRMADAS dentro del rango de fechas de juego.
═══════════════════════════════════════════════════════ */
require_once __DIR__ . '/admin_auth.php';
require_once __DIR__ . '/../../conexion.php';
require_once __DIR__ . '/../../config.php';

function fecha_valida(?string $f): bool
{
    $d = $f ? DateTime::createFromFormat('Y-m-d', $f) : false;
    return $d && $d->format('Y-m-d') === $f;
}

$desde    = $_GET['desde'] ?? date('Y-m-01');
$hasta    = $_GET['hasta'] ?? date('Y-m-d');
$canchaId = (int)($_GET['cancha_id'] ?? 0);
$formato  = $_GET['formato'] ?? 'json';

if (!fecha_valida($desde) || !fecha_valida($hasta)) {
    http_response_code(400);
    die(json_encode(['error' => 'Fechas inválidas (usa el formato AAAA-MM-DD).']));
}
if ($desde > $hasta) {
    http_response_code(400);
    die(json_encode(['error' => 'La fecha "desde" no puede ser posterior a "hasta".']));
}
if ((new DateTime($desde))->diff(new DateTime($hasta))->days > 366) {
    http_response_code(400);
    die(json_encode(['error' => 'El rango máximo del reporte es de un año.']));
}

$where  = "r.estado = 'confirmada' AND r.fecha BETWEEN ? AND ?";
$params = [$desde, $hasta];
if ($canchaId) {
    $where   .= " AND r.cancha_id = ?";
    $params[] = $canchaId;
}

// ── Detalle (una fila por reserva) ────────────────────
$stmt = $pdo->prepare("
    SELECT r.id, r.fecha, h.hora AS horario, c.nombre AS cancha, c.tipo,
           r.nombre_jugador, r.email, r.telefono, r.jugadores, r.precio_pagado,
           COALESCE(p.metodo, 'sin pago') AS metodo_pago,
           COALESCE(p.estado, 'pendiente') AS estado_pago,
           p.referencia
    FROM reservas r
    JOIN canchas  c ON c.id = r.cancha_id
    JOIN horarios h ON h.id = r.horario_id
    LEFT JOIN pagos p ON p.reserva_id = r.id
    WHERE $where
    ORDER BY r.fecha, h.hora
");
$stmt->execute($params);
$detalle = $stmt->fetchAll();

// ── Exportar CSV ──────────────────────────────────────
if ($formato === 'csv') {
    // Neutraliza "inyección de fórmulas": una celda que empiece con = + - @
    // se ejecutaría como fórmula al abrir el CSV en Excel.
    $seguro = function ($v) {
        $v = (string)$v;
        return ($v !== '' && strpos("=+-@\t\r", $v[0]) !== false) ? "'" . $v : $v;
    };

    header_remove('Content-Type');
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="ingresos_canchaya_' . $desde . '_a_' . $hasta . '.csv"');

    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");   // BOM UTF-8: Excel muestra bien las tildes y la ñ
    fputcsv($out, ['ID', 'Fecha', 'Hora', 'Cancha', 'Tipo', 'Jugador', 'Correo', 'Teléfono',
                   'Jugadores', 'Monto (USD)', 'Método de pago', 'Estado del pago', 'Referencia']);
    $total = 0;
    foreach ($detalle as $d) {
        $total += (float)$d['precio_pagado'];
        fputcsv($out, [
            $d['id'], $d['fecha'], substr($d['horario'], 0, 5), $seguro($d['cancha']), $seguro($d['tipo']),
            $seguro($d['nombre_jugador']), $seguro($d['email']), $seguro($d['telefono']),
            $d['jugadores'], number_format((float)$d['precio_pagado'], 2, '.', ''),
            $d['metodo_pago'], $d['estado_pago'], $seguro($d['referencia']),
        ]);
    }
    fputcsv($out, ['', '', '', '', '', '', '', 'TOTAL', count($detalle), number_format($total, 2, '.', ''), '', '', '']);
    fclose($out);
    exit;
}

// ── Resumen para pantalla ─────────────────────────────
$ingresos = $cobrado = $porCobrar = 0.0;
$porDia = $porCancha = [];
foreach ($detalle as $d) {
    $m = (float)$d['precio_pagado'];
    $ingresos += $m;
    if ($d['estado_pago'] === 'pagado') $cobrado   += $m;
    else                                $porCobrar += $m;

    $porDia[$d['fecha']] = ($porDia[$d['fecha']] ?? 0) + $m;

    $k = $d['cancha'];
    $porCancha[$k] ??= ['cancha' => $k, 'reservas' => 0, 'ingresos' => 0.0];
    $porCancha[$k]['reservas']++;
    $porCancha[$k]['ingresos'] += $m;
}
usort($porCancha, fn($a, $b) => $b['ingresos'] <=> $a['ingresos']);

$dias = [];
foreach ($porDia as $f => $m) $dias[] = ['fecha' => $f, 'ingresos' => round($m, 2)];

echo json_encode([
    'desde'  => $desde,
    'hasta'  => $hasta,
    'resumen' => [
        'reservas'        => count($detalle),
        'ingresos'        => round($ingresos, 2),
        'cobrado'         => round($cobrado, 2),     // pagado en línea
        'por_cobrar'      => round($porCobrar, 2),   // pagará en la cancha
        'ticket_promedio' => count($detalle) ? round($ingresos / count($detalle), 2) : 0,
    ],
    'por_dia'    => $dias,
    'por_cancha' => array_map(fn($c) => ['cancha' => $c['cancha'], 'reservas' => $c['reservas'], 'ingresos' => round($c['ingresos'], 2)], $porCancha),
]);
