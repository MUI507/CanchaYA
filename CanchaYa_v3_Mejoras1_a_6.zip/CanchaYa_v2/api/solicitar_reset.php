<?php
/* ═══════════════════════════════════════════════════════
   solicitar_reset.php — Mejora 1: Recuperación de contraseña
   Paso 1: el usuario ingresa su correo → se genera un token
   único (expira en 30 min) y se envía el enlace por correo.
═══════════════════════════════════════════════════════ */

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../conexion.php';
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/mailer.php';

$data  = json_decode(file_get_contents('php://input'), true);
$email = trim($data['email'] ?? '');

if (!$email) {
    http_response_code(400);
    die(json_encode(['error' => 'Ingresa tu correo electrónico.']));
}

// Mensaje genérico de respuesta: por seguridad, NUNCA revelamos si el
// correo existe o no en la base de datos (evita que alguien use este
// formulario para averiguar qué correos están registrados).
$mensajeGenerico = 'Si el correo está registrado, te enviaremos un enlace para restablecer tu contraseña.';

$stmt = $pdo->prepare('SELECT id, nombre, email FROM usuarios WHERE email = ?');
$stmt->execute([$email]);
$usuario = $stmt->fetch();

if ($usuario) {
    // Invalida cualquier token anterior del usuario que siga vigente.
    $pdo->prepare('DELETE FROM password_resets WHERE usuario_id = ?')->execute([$usuario['id']]);

    $token    = bin2hex(random_bytes(32)); // 64 caracteres, impredecible
    $expiraEn = date('Y-m-d H:i:s', strtotime('+' . RESET_TOKEN_MINUTOS . ' minutes'));

    $stmt = $pdo->prepare(
        'INSERT INTO password_resets (usuario_id, token, expira_en) VALUES (?, ?, ?)'
    );
    $stmt->execute([$usuario['id'], $token, $expiraEn]);

    $enlace = SITE_URL . '/index.html?reset_token=' . $token;

    $asunto = 'Recupera tu contraseña — CanchaYa';
    $cuerpo = "
        <p>Hola " . htmlspecialchars($usuario['nombre']) . ",</p>
        <p>Recibimos una solicitud para restablecer tu contraseña en CanchaYa.</p>
        <p><a href=\"$enlace\">Haz clic aquí para definir una nueva contraseña</a></p>
        <p>Este enlace expira en " . RESET_TOKEN_MINUTOS . " minutos. Si tú no solicitaste este cambio, puedes ignorar este correo.</p>
        <p>— El equipo de CanchaYa</p>
    ";

    enviar_correo($usuario['email'], $asunto, $cuerpo);
}

// Se responde igual exista o no el usuario.
echo json_encode(['ok' => true, 'mensaje' => $mensajeGenerico]);
