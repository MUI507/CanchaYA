<?php
/* Mejora 5 — Crea una reseña para una reserva ya jugada.
   POST { reserva_id, calificacion (1-5), comentario? }
   Reglas: sesión iniciada · la reserva es del usuario · está confirmada ·
           ya se jugó · una sola reseña por reserva. */
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../conexion.php';
require_once __DIR__ . '/../config.php';   // zona horaria de Panamá
session_start();

$sesion = $_SESSION['usuario'] ?? null;
if (!$sesion) {
    http_response_code(401);
    die(json_encode(['error' => 'Debes iniciar sesión para dejar una reseña.']));
}

$data         = json_decode(file_get_contents('php://input'), true);
$reservaId    = (int)($data['reserva_id'] ?? 0);
$calificacion = (int)($data['calificacion'] ?? 0);
$comentario   = trim((string)($data['comentario'] ?? ''));

if (!$reservaId) {
    http_response_code(400);
    die(json_encode(['error' => 'Falta el id de la reserva.']));
}
if ($calificacion < 1 || $calificacion > 5) {
    http_response_code(400);
    die(json_encode(['error' => 'La calificación debe ser de 1 a 5 estrellas.']));
}
if (preg_match_all("/./us", $comentario) > 500) {   // cuenta caracteres (no bytes) sin requerir mbstring
    http_response_code(400);
    die(json_encode(['error' => 'El comentario no puede superar los 500 caracteres.']));
}

$stmt = $pdo->prepare("
    SELECT r.id, r.cancha_id, r.usuario_id, r.email, r.fecha, r.estado, h.hora
    FROM reservas r JOIN horarios h ON h.id = r.horario_id
    WHERE r.id = ?
");
$stmt->execute([$reservaId]);
$r = $stmt->fetch();

if (!$r) {
    http_response_code(404);
    die(json_encode(['error' => 'Reserva no encontrada.']));
}
$esDueno = ((int)$r['usuario_id'] === (int)$sesion['id']) || strcasecmp($r['email'], $sesion['email']) === 0;
if (!$esDueno) {
    http_response_code(403);
    die(json_encode(['error' => 'Solo puedes calificar tus propias reservas.']));
}
if ($r['estado'] !== 'confirmada') {
    http_response_code(409);
    die(json_encode(['error' => 'No se puede calificar una reserva cancelada.']));
}
if (fecha_hora_panama($r['fecha'], $r['hora']) > ahora_panama()) {
    http_response_code(409);
    die(json_encode(['error' => 'Podrás calificar la cancha después de jugar tu reserva.']));
}

try {
    $stmt = $pdo->prepare("
        INSERT INTO resenas (cancha_id, usuario_id, reserva_id, calificacion, comentario)
        VALUES (?, ?, ?, ?, ?)
    ");
    $stmt->execute([$r['cancha_id'], $sesion['id'], $reservaId, $calificacion, $comentario !== '' ? $comentario : null]);
} catch (PDOException $e) {
    if ($e->getCode() == 23000) {
        http_response_code(409);
        die(json_encode(['error' => 'Ya calificaste esta reserva.']));
    }
    error_log('Error al guardar reseña: ' . $e->getMessage());
    http_response_code(500);
    die(json_encode(['error' => 'No se pudo guardar la reseña.']));
}

echo json_encode(['ok' => true]);
