<?php
/* ═══════════════════════════════════════════════════════
   pagos.php — CanchaYa  (Mejora 4: pagos en línea)

   Capa de pagos con dos modos (PAGOS_MODO en config.php):
     · 'simulado'   → pasarela de pruebas, no mueve dinero real.
     · 'produccion' → llama a cobrar_tarjeta_real() / cobrar_yappy_real(),
                      que deben conectarse a la pasarela contratada.

   Seguridad: el número completo de la tarjeta y el CVV se usan solo
   para validar/cobrar en la misma petición. NUNCA se guardan en la BD
   ni en logs; de la tarjeta solo se conservan los últimos 4 dígitos.
═══════════════════════════════════════════════════════ */

require_once __DIR__ . '/../config.php';

/** Algoritmo de Luhn: detecta números de tarjeta mal digitados. */
function luhn_valido(string $numero): bool
{
    $suma = 0;
    $alt  = false;
    for ($i = strlen($numero) - 1; $i >= 0; $i--) {
        $d = (int)$numero[$i];
        if ($alt) {
            $d *= 2;
            if ($d > 9) $d -= 9;
        }
        $suma += $d;
        $alt = !$alt;
    }
    return $suma % 10 === 0;
}

/**
 * Cobra un monto. Devuelve:
 *   ['ok' => true,  'referencia' => '...', 'ultimos4' => '1234'|null, 'estado' => 'pagado'|'pendiente']
 *   ['ok' => false, 'error' => 'mensaje para el usuario']
 *
 * @param string $metodo  'tarjeta' | 'yappy' | 'efectivo'
 * @param array  $datos   Datos del medio de pago (tarjeta: numero, vence, cvv, titular / yappy: celular)
 */
function procesar_pago(string $metodo, float $monto, array $datos): array
{
    if ($metodo === 'efectivo') {
        // Pago en la cancha: queda pendiente hasta que el administrador lo cobre.
        return ['ok' => true, 'referencia' => null, 'ultimos4' => null, 'estado' => 'pendiente'];
    }

    if ($metodo === 'tarjeta') {
        $numero  = preg_replace('/\D/', '', (string)($datos['numero'] ?? ''));
        $vence   = trim((string)($datos['vence'] ?? ''));      // MM/AA
        $cvv     = preg_replace('/\D/', '', (string)($datos['cvv'] ?? ''));
        $titular = trim((string)($datos['titular'] ?? ''));

        if (strlen($numero) < 13 || strlen($numero) > 19 || !luhn_valido($numero)) {
            return ['ok' => false, 'error' => 'El número de tarjeta no es válido.'];
        }
        if (!preg_match('/^(0[1-9]|1[0-2])\/(\d{2})$/', $vence, $m)) {
            return ['ok' => false, 'error' => 'La fecha de vencimiento debe tener el formato MM/AA.'];
        }
        // La tarjeta vence el último día del mes indicado
        $finMes = DateTime::createFromFormat('Y-m-d', '20' . $m[2] . '-' . $m[1] . '-01');
        $finMes->modify('last day of this month')->setTime(23, 59, 59);
        if ($finMes < new DateTime()) {
            return ['ok' => false, 'error' => 'La tarjeta está vencida.'];
        }
        if (strlen($cvv) < 3 || strlen($cvv) > 4) {
            return ['ok' => false, 'error' => 'El CVV debe tener 3 o 4 dígitos.'];
        }
        if ($titular === '') {
            return ['ok' => false, 'error' => 'Ingresa el nombre del titular de la tarjeta.'];
        }

        // Tarjeta de prueba que la pasarela simulada siempre rechaza
        if (PAGOS_MODO !== 'produccion' && $numero === '4000000000000002') {
            return ['ok' => false, 'error' => 'La tarjeta fue rechazada por el banco emisor.'];
        }

        $res = (PAGOS_MODO === 'produccion')
            ? cobrar_tarjeta_real($monto, $numero, $vence, $cvv, $titular)
            : cobrar_simulado('TRJ');
        if (!$res['ok']) return $res;

        $res['ultimos4'] = substr($numero, -4);
        $res['estado']   = 'pagado';

        // Higiene: borrar de memoria los datos sensibles lo antes posible
        $numero = $cvv = '';
        return $res;
    }

    if ($metodo === 'yappy') {
        $celular = preg_replace('/\D/', '', (string)($datos['celular'] ?? ''));
        // Celulares de Panamá: 8 dígitos (con o sin el 507 delante)
        if (strlen($celular) === 11 && strpos($celular, '507') === 0) {
            $celular = substr($celular, 3);
        }
        if (!preg_match('/^6\d{7}$/', $celular)) {
            return ['ok' => false, 'error' => 'Ingresa un celular de Yappy válido (8 dígitos, empieza con 6).'];
        }

        $res = (PAGOS_MODO === 'produccion')
            ? cobrar_yappy_real($monto, $celular)
            : cobrar_simulado('YPY');
        if (!$res['ok']) return $res;

        $res['ultimos4'] = null;
        $res['estado']   = 'pagado';
        return $res;
    }

    return ['ok' => false, 'error' => 'Método de pago no soportado.'];
}

/** Pasarela de pruebas: aprueba todo salvo la tarjeta de prueba 4000 0000 0000 0002. */
function cobrar_simulado(string $prefijo): array
{
    return ['ok' => true, 'referencia' => $prefijo . '-SIM-' . strtoupper(bin2hex(random_bytes(5)))];
}

/* ── Conectores reales (por implementar al contratar la pasarela) ──
   Se dejan fallando de forma explícita para que nadie crea que se está
   cobrando dinero real sin haber configurado las credenciales. */
function cobrar_tarjeta_real(float $monto, string $numero, string $vence, string $cvv, string $titular): array
{
    // Con una pasarela real (PagueloFacil, Stripe, etc.) lo correcto es NO
    // recibir el número de tarjeta en este servidor, sino usar el formulario
    // alojado / tokenización de la pasarela y cobrar con el token.
    error_log('PAGOS_MODO=produccion pero cobrar_tarjeta_real() no está implementada.');
    return ['ok' => false, 'error' => 'El cobro con tarjeta aún no está habilitado. Elige otro método.'];
}

function cobrar_yappy_real(float $monto, string $celular): array
{
    // Requiere YAPPY_MERCHANT_ID / YAPPY_API_KEY y la API de Yappy Comercial.
    error_log('PAGOS_MODO=produccion pero cobrar_yappy_real() no está implementada.');
    return ['ok' => false, 'error' => 'El cobro con Yappy aún no está habilitado. Elige otro método.'];
}

/** Marca como reembolsado el pago de una reserva cancelada (si estaba pagado). */
function reembolsar_reserva(PDO $pdo, int $reservaId): bool
{
    $stmt = $pdo->prepare("UPDATE pagos SET estado = 'reembolsado' WHERE reserva_id = ? AND estado = 'pagado'");
    $stmt->execute([$reservaId]);
    // En producción aquí se llamaría a la API de la pasarela para devolver el dinero.
    return $stmt->rowCount() > 0;
}
