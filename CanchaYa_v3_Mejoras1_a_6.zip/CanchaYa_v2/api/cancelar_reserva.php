<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../conexion.php';
require_once __DIR__ . '/mailer.php';
require_once __DIR__ . '/pagos.php';
session_start();

$data       = json_decode(file_get_contents('php://input'), true);
$reservaId  = (int)($data['reserva_id'] ?? 0);

if (!$reservaId) {
    http_response_code(400);
    die(json_encode(['error' => 'Falta el id de la reserva.']));
}

// Con pagos y reembolsos de por medio, solo el dueño de la reserva (o un
// administrador) puede cancelarla. Antes bastaba con conocer el id.
$sesion = $_SESSION['usuario'] ?? null;
if (!$sesion) {
    http_response_code(401);
    die(json_encode(['error' => 'Debes iniciar sesión para cancelar una reserva.']));
}

$stmt = $pdo->prepare("SELECT r.usuario_id, r.email, r.estado, r.fecha, h.hora FROM reservas r JOIN horarios h ON h.id = r.horario_id WHERE r.id = ?");
$stmt->execute([$reservaId]);
$reserva = $stmt->fetch();

if (!$reserva) {
    http_response_code(404);
    die(json_encode(['error' => 'Reserva no encontrada.']));
}
$esDueno = ((int)$reserva['usuario_id'] === (int)$sesion['id']) || strcasecmp($reserva['email'], $sesion['email']) === 0;
if (!$esDueno && $sesion['rol'] !== 'admin') {
    http_response_code(403);
    die(json_encode(['error' => 'Esta reserva no te pertenece.']));
}
if ($reserva['estado'] !== 'confirmada') {
    http_response_code(409);
    die(json_encode(['error' => 'La reserva ya estaba cancelada.']));
}

// Una reserva ya jugada no se cancela ni se reembolsa (un admin sí puede, desde su panel)
if ($sesion['rol'] !== 'admin' && fecha_hora_panama($reserva['fecha'], $reserva['hora']) <= ahora_panama()) {
    http_response_code(409);
    die(json_encode(['error' => 'Esta reserva ya se jugó y no se puede cancelar.']));
}

$stmt = $pdo->prepare("UPDATE reservas SET estado = 'cancelada' WHERE id = ? AND estado = 'confirmada'");
$stmt->execute([$reservaId]);

if ($stmt->rowCount() > 0) {
    reembolsar_reserva($pdo, $reservaId);   // Mejora 4: marca el pago como reembolsado
    try {
        notificar_reserva($pdo, $reservaId, 'cancelada');
    } catch (\Throwable $e) {
        error_log('No se pudo enviar la notificación de cancelación: ' . $e->getMessage());
    }
}

echo json_encode(['ok' => true]);
