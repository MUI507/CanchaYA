<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../conexion.php';
require_once __DIR__ . '/mailer.php';
require_once __DIR__ . '/pagos.php';
session_start();

$data       = json_decode(file_get_contents('php://input'), true);
$canchaId   = $data['cancha_id']  ?? null;
$horaTexto  = $data['horario']    ?? null;   // ej: "14:00"
$fecha      = $data['fecha']      ?? date('Y-m-d');
$nombre     = trim($data['nombre'] ?? '');
$telefono   = trim($data['tel'] ?? '');
$email      = trim($data['email'] ?? '');
$jugadores  = (int)($data['jugadores'] ?? 0);

// Mejora 4: método de pago ('tarjeta' | 'yappy' | 'efectivo') y sus datos
$metodoPago = $data['metodo_pago'] ?? 'efectivo';
$datosPago  = is_array($data['pago'] ?? null) ? $data['pago'] : [];

if (!$canchaId || !$horaTexto || !$nombre || !$email) {
    http_response_code(400);
    die(json_encode(['error' => 'Faltan datos obligatorios.']));
}

// Mejora 3: no permitir reservar fechas pasadas ni demasiado lejanas
// (el selector del frontend ya limita esto, pero se valida también aquí
// por si la petición llega directo a la API).
$hoy      = new DateTime('today');
$fechaObj = DateTime::createFromFormat('Y-m-d', $fecha);
if (!$fechaObj) {
    http_response_code(400);
    die(json_encode(['error' => 'Fecha inválida.']));
}
if ($fechaObj < $hoy) {
    http_response_code(400);
    die(json_encode(['error' => 'No puedes reservar una fecha pasada.']));
}
$maxFecha = (clone $hoy)->modify('+30 days');
if ($fechaObj > $maxFecha) {
    http_response_code(400);
    die(json_encode(['error' => 'Solo puedes reservar con hasta 30 días de anticipación.']));
}

// Buscar id del horario a partir de la hora (ej "14:00")
$stmt = $pdo->prepare("SELECT id FROM horarios WHERE hora = ?");
$stmt->execute([$horaTexto]);
$horario = $stmt->fetch();
if (!$horario) {
    http_response_code(400);
    die(json_encode(['error' => 'Horario inválido.']));
}
$horarioId = $horario['id'];

// Buscar precio de la cancha
$stmt = $pdo->prepare("SELECT precio FROM canchas WHERE id = ?");
$stmt->execute([$canchaId]);
$cancha = $stmt->fetch();
if (!$cancha) {
    http_response_code(404);
    die(json_encode(['error' => 'Cancha no encontrada.']));
}

$usuarioId = $_SESSION['usuario']['id'] ?? null;
$monto     = (float)$cancha['precio'];   // el precio SIEMPRE sale de la BD, nunca del cliente

// La reserva y el cobro van en una sola transacción:
//   1) se inserta la reserva (la restricción UNIQUE reserva el horario)
//   2) se cobra; si el cobro falla se hace rollback y el horario queda libre
//   3) se registra el pago y se confirma todo
try {
    $pdo->beginTransaction();

    $stmt = $pdo->prepare("
        INSERT INTO reservas (cancha_id, horario_id, usuario_id, fecha, nombre_jugador, telefono, email, jugadores, precio_pagado)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([$canchaId, $horarioId, $usuarioId, $fecha, $nombre, $telefono, $email, $jugadores, $monto]);
    $reservaId = (int)$pdo->lastInsertId();

    $pago = procesar_pago($metodoPago, $monto, $datosPago);
    if (!$pago['ok']) {
        $pdo->rollBack();
        http_response_code(402);
        die(json_encode(['error' => $pago['error']]));
    }

    $stmt = $pdo->prepare("
        INSERT INTO pagos (reserva_id, metodo, monto, estado, referencia, tarjeta_ultimos4)
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([$reservaId, $metodoPago, $monto, $pago['estado'], $pago['referencia'], $pago['ultimos4']]);

    $pdo->commit();
} catch (PDOException $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    // Choca con la restricción UNIQUE (cancha_id, fecha, horario_id, slot_activo)
    if ($e->getCode() == 23000) {
        http_response_code(409);
        die(json_encode(['error' => 'Ese horario ya fue reservado. Elige otro.']));
    }
    error_log('Error al crear la reserva: ' . $e->getMessage());
    http_response_code(500);
    die(json_encode(['error' => 'Error al crear la reserva.']));
}

echo json_encode([
    'ok'          => true,
    'reserva_id'  => $reservaId,
    'pago_estado' => $pago['estado'],
    'referencia'  => $pago['referencia'],
]);

// Notificación por correo/SMS (Mejora 2) — no debe romper la respuesta si falla.
try {
    notificar_reserva($pdo, $reservaId, 'confirmada');
} catch (\Throwable $e) {
    error_log('No se pudo enviar la notificación de reserva: ' . $e->getMessage());
}
