<?php
/* Mejora 5 — Lista las reseñas de una cancha + su promedio.
   GET resenas_listar.php?cancha_id=1 */
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../conexion.php';

$canchaId = (int)($_GET['cancha_id'] ?? 0);
if (!$canchaId) {
    http_response_code(400);
    die(json_encode(['error' => 'Falta cancha_id.']));
}

$stmt = $pdo->prepare("SELECT COALESCE(ROUND(AVG(calificacion), 1), 0) AS promedio, COUNT(*) AS total FROM resenas WHERE cancha_id = ?");
$stmt->execute([$canchaId]);
$resumen = $stmt->fetch();

// Solo se expone el primer nombre del autor (privacidad); nunca el correo.
$stmt = $pdo->prepare("
    SELECT SUBSTRING_INDEX(u.nombre, ' ', 1) AS autor, r.calificacion, r.comentario, r.creado_en
    FROM resenas r
    JOIN usuarios u ON u.id = r.usuario_id
    WHERE r.cancha_id = ?
    ORDER BY r.creado_en DESC
    LIMIT 50
");
$stmt->execute([$canchaId]);

echo json_encode([
    'promedio' => (float)$resumen['promedio'],
    'total'    => (int)$resumen['total'],
    'resenas'  => $stmt->fetchAll(),
]);
